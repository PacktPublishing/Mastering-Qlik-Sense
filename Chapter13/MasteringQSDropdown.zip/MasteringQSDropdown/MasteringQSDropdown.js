define(['qlik', './properties', 'text!./template.html', 'css!./MasteringQSDropdown.css'],

    function(qlik, properties, template) { 
    return { 
        snapshot: {
            canTakeSnapshot: false
        },
        definition: properties,
        paint: function(){},
        resize: function(){},
        template: template,
        controller: ['$scope', '$element', function (scope, $element) {

            //Get list of values
            var obj = {
                    "qDef": {
                        "qFieldDefs": [
                            scope.layout.field
                        ]
                    },
                    "qFrequencyMode": scope.layout.includeFrequency ? "EQ_NX_FREQUENCY_VALUE" : "NX_FREQUENCY_NONE",
                    "qInitialDataFetch": [{
                            qTop : 0,
                            qLeft : 0,
                            qHeight : 10000,
                            qWidth : 1
                        }]
                    };

            var app = qlik.currApp();

            //Create the listbox as a session object which will persist over the sesion and then be deleted.
            app.createList(obj,function(listobject) {       
                console.log(listobject)
                //Define dimension title
                scope.dimension_title = listobject.qListObject.qDimensionInfo.qFallbackTitle

                //Define Dimension value
                scope.dimension_values = listobject.qListObject.qDataPages[0].qMatrix.map(function(row){
                    return {
                        title: row[0].qText,
                        element_id: row[0].qElemNumber,
                        selection_state: row[0].qState,
                        frequency: scope.layout.includeFrequency && typeof row[0].qFrequency !== "undefined" ? '- ' + row[0].qFrequency : ''
                    }
                })
            }) 

            scope.$watch('selectedValue', function() {
                    if(typeof scope.selectedValue !== "undefined" && !scope.layout.readonly){
                        app.field(scope.layout.field).select([parseInt(scope.selectedValue,0)])
                    }
                });      
        }]
    }
});