define([], 
    function(){ 
        return {
            type: "items", 
            component: "accordion", 
            items: { 
                settings: {
                    type: "items",
                    label: "Settings", 
                    items: {                                                    
                        MasteringQSDropdown: { 
                            type: "string",  
                            label: "Dropdown Field", 
                            ref: "field", 
                            expression: "optional"     
                            },
                        includeFrequency: { 
                            label: "Include Frequency",
                            ref: "includeFrequency",
                            type: "boolean", 
                            defaultValue: false
                        },
                        ReadOnly: { 
                            label: "Read Only",
                            ref: "readonly",
                            type: "boolean", 
                            defaultValue: false
                        }
                        }                     
                    } 
            }
    };
});