define([], 
    function(){ 
        return {
            type: "items", 
            component: "accordion", 
            items: { 
                dimensions: { 
                    uses: "dimensions",
                    min: 1,
                    max: 1 
                }, 
                measures: { 
                    uses: "measures",
                    min: 1,
                    max: 1, 
                },
                sorting: {
                    uses: "sorting"
                }, 
                addons: { 
                    uses: "addons"
                }, 
                settings: { 
                    uses: "settings",
                    items: {
                        barColor: {
                            label: "Bar Color",
                            component: "color-picker",
                            type: "object",
                            dualOutput: true,
                            schemaIgnore: true,
                            ref: "barColor",
                            defaultValue: {
                                color: "#657dbc",
                                index: -1
                            },
                            show: function (layout) {
                                //Sets default value
                                if (typeof (layout.barColor) == 'undefined') {
                                    var defValue = {
                                        color: "#657dbc",
                                        index: -1
                                    };
                                    layout.barColor = defValue;
                                }
                                return true
                            }
                        },
                        }                                     
                    } 
            }
    };
});